import SpriteKit
import GameplayKit
import AVFoundation

class GameScene: SKScene {
  
    var backgroundMusicPlayer: AVAudioPlayer?
    
    let title = SKLabelNode( text: "The Main Scene")
    
        override func didMove(to view:SKView)
    {
        
        
        run(SKAction.wait(forDuration: 1.0)) {
                   self.transitionToLevels()
               }
        
        
        
          run(SKAction.sequence([
         SKAction.wait(forDuration: 0), // Wait 5 seconds, for example
         SKAction.run {
         self.presentMenuScene()
         //self.presentEndScene()
         }
         ]))
         
         
         }
         
         
         func presentMenuScene() {
         // Initialize the Menu scene
         let menuScene = Menu(size: self.size)
         menuScene.scaleMode = .aspectFill
         self.view?.presentScene(menuScene, transition: SKTransition.crossFade(withDuration: 1.0))
         }
    func transitionToLevels() {
           let levelsScene = Levels(size: self.size)
           levelsScene.scaleMode = .aspectFill
           self.view?.presentScene(levelsScene, transition: SKTransition.crossFade(withDuration: 1.0))
       }
         
         
     /*    func backgroundSetUp(_ background: SKSpriteNode ) {
         //  let size = self.size
         background.size=CGSize(width: 2796, height: 1290)
         background.position = CGPoint(x: frame.midX, y: frame.midY)
         
         */
         
         
    

}
