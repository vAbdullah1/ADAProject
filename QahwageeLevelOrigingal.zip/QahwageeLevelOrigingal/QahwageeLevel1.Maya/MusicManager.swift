//
//  MusicManager.swift
//  Qahwagee4
//
//  Created by maya on 11/02/1446 AH.
//
import AVFoundation
class MusicManager {
    static let shared = MusicManager()
    var audioPlayer: AVAudioPlayer?
    var isMuted = false
    
    private init() {}

    func startMusic() {
        if audioPlayer == nil {
            if let musicURL = Bundle.main.url(forResource: "Music", withExtension: "mp3") {
                do {
                    audioPlayer = try AVAudioPlayer(contentsOf: musicURL)
                    audioPlayer?.numberOfLoops = -1 // Loop indefinitely
                    audioPlayer?.prepareToPlay()
                } catch {
                    print("Error loading background music: \(error)")
                }
            }
        }
        if !isMuted {
            audioPlayer?.play()
        }
    }
    
    func pauseMusic() {
        audioPlayer?.pause()
    }

    func resumeMusic() {
        guard let player = audioPlayer, !isMuted else { return }
        player.play()
    }

    func toggleMute() {
        isMuted.toggle()
        if isMuted {
            audioPlayer?.pause()
        } else {
            audioPlayer?.play()
        }
    }
    
    func stopMusic() {
        audioPlayer?.stop()
        audioPlayer = nil
    }
    
    func setupAudioSession() {
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default, options: [.mixWithOthers])
            try AVAudioSession.sharedInstance().setActive(true)
        } catch {
            print("Failed to set up AVAudioSession: \(error)")
        }
    }
}
