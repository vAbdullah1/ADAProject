import SpriteKit
import GameplayKit
import AVFoundation

//level 1
class PlayScene: SKScene {

    var fireAnimationAction: SKAction?
    var Qahwagee: QahwageeMovement!
    var guests: [GuestMovement] = []
    var dallah: Dallah!
    var timerManager: TimerManager!
    var timerLabel: SKLabelNode!
    var guestBars: [GuestBar] = []
    var guestBar: GuestBar!
    var cupArray: [Cup] = []
    var guestCup: Cup!
    var cupCounter: CupCounter!
    var fireSoundPlayer: AVAudioPlayer?
    var musicPlayer: AVAudioPlayer?
    var onlyOnce: Bool = true
    var puse: Puse!

    override func didMove(to view: SKView) {

        //Background
        setupBackground()
        setupFireAnimation()
        setUpDallahs()
        playFireSound()
       
        
        if areGuestsSitting() && onlyOnce {
            onlyOnce = false
            playBackgroundMusic()
        }

        setupPauseMenu()
        
        // Characters
        setupCharacterMovement()
        setupGuests()
        startGuestMovement(delay: 4.0)

        // Progress Bar & Timer
        setupProgressBar()
        setupTimer()

        // Setup cup count labels
        setupCoffeeCountLabel()
        setUpCoffeeCups()
    }

    //Constantly calls the functions
    override func update(_ currentTime: TimeInterval) {
        setGuestBarForAll()

        for bar in guestBars {
            if bar.hasBarReachedSeventyPercent() {
                delay(2.0) {
                    self.didReachSeventyPercent(for: bar)
                }
            }
        }

        // Check for win/lose condition
        if timerManager.timeLeft <= 0 {
            if Cup.brokenCupCount <= 2 {
                transitionToGoodJobScene()
            } else if Cup.brokenCupCount >= 3 {
                transitionToGameOver()
            }
        }
    }

    func transitionToGoodJobScene() {
        let goodJobScene = GoodJobScene(size: self.size)
        goodJobScene.scaleMode = .aspectFill
        let transition = SKTransition.fade(withDuration: 1.0)
        self.view?.presentScene(goodJobScene, transition: transition)
    }

    func transitionToGameOver() {
        let gameOverScene = GameOverScene(size: self.size)
        gameOverScene.scaleMode = .aspectFill
        let transition = SKTransition.fade(withDuration: 1.0)
        self.view?.presentScene(gameOverScene, transition: transition)
    }

    //Make a delay
    func delay(_ delay: TimeInterval, closure: @escaping () -> Void) {
        DispatchQueue.main.asyncAfter(deadline: .now() + delay, execute: closure)
    }

    //Characters Functions

    func setupCharacterMovement() {
        let initialPosition = CGPoint(x: 640, y: -160)
        Qahwagee = QahwageeMovement(initialPosition: initialPosition)
        Qahwagee.addCharacter(to: self)
    }

    func setupGuests() {
        let guestArea = ["Area6", "Area7", "Area5", "Area8"]
        for (index, areaName) in guestArea.enumerated() {
            let guest = GuestMovement(path: "path\(index + 1)", guestName: "guest\(index + 1)", guestArea: areaName, GuestType: "guest")
            guests.append(guest)
        }
    }

    func startGuestMovement(delay: TimeInterval) {
        for (index, guest) in guests.enumerated() {
            DispatchQueue.main.asyncAfter(deadline: .now() + delay * TimeInterval(index)) {
                guest.startMovement(scene: self)
            }
        }
    }

    func setUpCoffeeCups() {
        for guest in guests {
            let guestPaths = guest.paths
            for (pathName, pathPoints) in guestPaths {
                if guest.guestPath == pathName {
                    let xPosition = pathPoints[1].x
                    guestCup = Cup(xPosition: xPosition)
                    cupArray.append(guestCup)
                }
            }
        }
    }

    func setupGuestBar(at x: CGFloat) {
        let xSettingPoint = x
        let ySettingPoint = 373.00
        let guestBar = GuestBar(xPosition: xSettingPoint, yPosition: ySettingPoint)

        guestBar.position = CGPoint(x: xSettingPoint, y: ySettingPoint)
        guestBar.zPosition = 10
        addChild(guestBar)
        guestBars.append(guestBar)
        guestBar.startProgressAnimation(duration: 10.0)
    }

    func didReachSeventyPercent(for guestBar: GuestBar) {
        for guest in guests {
            for cup in cupArray {
                if guest.character.position.x == guestBar.position.x && guest.hasDrink == false &&
                    guest.character.position.x == cup.position.x {

                    guestBar.removeFromParent()

                    if guest.character.hasActions() == false {
                        guest.exitMovement()
                        self.cupCounter.dropCupCount()
                        cup.drop(in: self)

                        if let index = cupArray.firstIndex(of: cup) {
                            cupArray.remove(at: index)
                        }
                        break
                    }
                }
            }
        }
    }

    func setGuestBarForAll() {
        for guest in guests {
            if guest.character.position.y == 254.00 {
                var shouldAddBar = true
                for bar in guestBars {
                    if bar.position.x == guest.character.position.x {
                        shouldAddBar = false
                        break
                    }
                }
                if shouldAddBar {
                    setupGuestBar(at: guest.character.position.x)
                }
            }
        }
    }

    func setupCoffeeCountLabel() {
        cupCounter = CupCounter(maxCups: 3, scene: self)
    }

    private func setupTimer() {
        timerLabel = SKLabelNode(fontNamed: "PressStart2P-Regular")
        timerLabel.position = CGPoint(x: self.frame.midX - 1090, y: self.frame.midY + 418)
        timerManager = TimerManager(initialTime: 45, label: timerLabel, scene: self)
        timerManager.startTimer()
    }

    func setupProgressBar() {
        dallah = Dallah(maxSlots: 3, scene: self)
    }

    func setupPauseMenu() {
        puse = Puse()
        puse.setAudioPlayers(musicPlayer: musicPlayer, fireSoundPlayer: fireSoundPlayer)
        puse.position = CGPoint(x: 0, y: 0)
        puse.zPosition = 100
        addChild(puse)
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        let location = touch.location(in: self)

        Qahwagee.moveCharacter(to: location, duration: 2.0)

        if Qahwagee.isLocationFire(location: location) {
            dallah.refillProgressBar(delay: 2.0)
        } else if Qahwagee.isLocationChairs(location: location) {
            let result = findGuestAndGuestBar(at: location)

            if let guest = result.guest, let guestBar = result.guestBar {
                if !guestBar.hasBarReachedSeventyPercent() && !self.dallah.isDallahEmpty() {
                    delay(2.4) {
                        self.dallah.decreaseProgressBar(delay: 0)
                        if guest.character.hasActions() == false {
                            guestBar.removeFromParent()
                            guest.drinkingCharacter()
                            self.delay(4) {
                                guest.setCharacter()
                                self.delay(2) {
                                    guest.exitMovement2()
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    func isGuestsSitting(guest: GuestMovement) -> Bool {
        return guest.character.position.y == 254.00
    }

    func areGuestsSitting() -> Bool {
//        var sittingCount = 0
//        for guest in guests {
//            if guest.character.position.y == 254.00 {
//                sittingCount += 1
//            }
//            if sittingCount >= 2 {
//                return true
//            }
//        }
        return true
    }

    func isQahwageeNextToGuest(guest: GuestMovement) -> Bool {
        return Qahwagee.QahwageeArea == guest.guestArea
    }

    func findGuestAndGuestBar(at location: CGPoint) -> (guest: GuestMovement?, guestBar: GuestBar?) {
        for guest in guests {
            if isGuestsSitting(guest: guest) && isQahwageeNextToGuest(guest: guest) {
                for guestBar in guestBars {
                    if guest.character.position.x == guestBar.position.x {
                        return (guest, guestBar)
                    }
                }
            }
        }
        return (nil, nil)
    }

    // Background Functions

    func transitionToGameScene() {
        let gameScene = GameScene(size: self.size)
        gameScene.scaleMode = .aspectFill
        let transition = SKTransition.flipHorizontal(withDuration: 1.0)
        self.view?.presentScene(gameScene, transition: transition)
    }

    private func setupBackground() {
        let background = SKSpriteNode(imageNamed: "gamescreen")
        background.position = CGPoint(x: 0, y: 0)
        background.zPosition = -1
        background.size = CGSize(width: frame.width, height: frame.height)
        background.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        addChild(background)
    }

    private func setupButtons() {
        let button = SKSpriteNode(imageNamed: "buttonImage")
        button.position = CGPoint(x: self.size.width / 2, y: self.size.height / 4)
        button.name = "button"
        button.zPosition = 1
        addChild(button)
    }

    private func setupFireAnimation() {
        var textures: [SKTexture] = []
        for i in 29...32 {
            let textureName = "\(i).png"
            let texture = SKTexture(imageNamed: textureName)
            textures.append(texture)
        }
        textures.append(textures[2])
        textures.append(textures[1])

        let fireAnimationAction = SKAction.animate(with: textures, timePerFrame: 0.1)
        let fireNode = SKSpriteNode(texture: textures.first)
        fireNode.position = CGPoint(x: 3.624 / 2, y: -410.936)
        fireNode.size = CGSize(width: 340.491, height: 202.14)
        fireNode.zPosition = 2
        fireNode.run(SKAction.repeatForever(fireAnimationAction))
        addChild(fireNode)
    }

    func setUpDallahs() {
        let Shbak = SKSpriteNode(imageNamed: "Shbk")
        Shbak.position = CGPoint(x: 10.358, y: -402.02)
        Shbak.zPosition = 3
        Shbak.size = CGSize(width: 353.958, height: 184.309)
        Shbak.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        addChild(Shbak)

        let dallahSmallSize = CGSize(width: 79.663, height: 63.986)
        let dallahSmallPositions = [
            CGPoint(x: -84.462, y: -391.993),
            CGPoint(x: -13.532, y: -391.993),
            CGPoint(x: 61.662, y: -391.993)
        ]

        for position in dallahSmallPositions {
            let dallah = SKSpriteNode(imageNamed: "Dallah")
            dallah.position = position
            dallah.zPosition = 5
            dallah.size = dallahSmallSize
            dallah.anchorPoint = CGPoint(x: 0.5, y: 0.5)
            addChild(dallah)
        }

        let dallahBigSize = CGSize(width: 88.899, height: 75.835)
        let dallahBigPositions = [
            CGPoint(x: -55.394, y: -406.248),
            CGPoint(x: 23.624, y: -406.248),
            CGPoint(x: 104.77, y: -406.248)
        ]

        for position in dallahBigPositions {
            let dallah = SKSpriteNode(imageNamed: "Dallah")
            dallah.position = position
            dallah.zPosition = 6
            dallah.size = dallahBigSize
            dallah.anchorPoint = CGPoint(x: 0.5, y: 0.5)
            addChild(dallah)
        }
    }

    private func playFireSound() {
        if let soundURL = Bundle.main.url(forResource: "firesound", withExtension: "mp3") {
            do {
                fireSoundPlayer = try AVAudioPlayer(contentsOf: soundURL)
                fireSoundPlayer?.numberOfLoops = -1
                fireSoundPlayer?.volume = 0.5
                fireSoundPlayer?.prepareToPlay()
                fireSoundPlayer?.play()
                print("Fire sound started")
            } catch {
                print("Could not load fire sound file: \(error)")
            }
        }
    }

    private func playBackgroundMusic() {
        if let musicURL = Bundle.main.url(forResource: "talking", withExtension: "mp3") {
            do {
                musicPlayer = try AVAudioPlayer(contentsOf: musicURL)
                musicPlayer?.numberOfLoops = -1
                fireSoundPlayer?.volume = 0.1
                musicPlayer?.prepareToPlay()
                musicPlayer?.play()
                print("Background music started")
            } catch {
                print("Could not load music file: \(error)")
            }
        }
    }
}
