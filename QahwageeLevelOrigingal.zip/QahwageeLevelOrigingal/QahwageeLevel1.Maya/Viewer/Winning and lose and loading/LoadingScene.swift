import SpriteKit

class LoadingScene: SKScene {
    var gifFrames: [SKTexture] = []
    var gifNode: SKSpriteNode!

    override func didMove(to view: SKView) {
        backgroundColor = SKColor.black
        loadGifFrames()
        if !gifFrames.isEmpty {
            displayGif()
        }

        // تأكد من ضبط الحجم ونقطة الارتساء
        self.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        self.scaleMode = .aspectFill

        // بعد عرض الـ GIF، الانتقال إلى PlayScene
        let wait = SKAction.wait(forDuration: 4.0)
        let transition = SKAction.run {
            self.transitionToPlayScene()
        }
        self.run(SKAction.sequence([wait, transition]))
    }

    func loadGifFrames() {
        gifFrames.removeAll()
        for i in 1...11 { // عدد الفريمات لديك
            let imageName = "LoadingScene\(i)" // تأكد من تسمية الصور بشكل صحيح
            let texture = SKTexture(imageNamed: imageName)
            if texture.size() != CGSize.zero { // تأكد من أن الصورة تم تحميلها بنجاح
                gifFrames.append(texture)
            } else {
                print("Failed to load image named \(imageName)")
            }
        }
    }

    func displayGif() {
        guard let firstFrame = gifFrames.first else { return }
        gifNode = SKSpriteNode(texture: firstFrame)
        gifNode.position = CGPoint(x: frame.midX, y: frame.midY)
        
        // ضبط حجم الصورة لتتناسب مع نسبة العرض إلى الارتفاع للشاشة
        let aspectRatio = firstFrame.size().width / firstFrame.size().height
        var newWidth: CGFloat
        var newHeight: CGFloat
        
        // ضبط العرض والارتفاع حسب نسبة العرض إلى الارتفاع للشاشة
        if frame.width / frame.height > aspectRatio {
            newHeight = frame.height
            newWidth = newHeight * aspectRatio
        } else {
            newWidth = frame.width
            newHeight = newWidth / aspectRatio
        }
        
        gifNode.size = CGSize(width: newWidth, height: newHeight)
        
        addChild(gifNode)
        let animateAction = SKAction.animate(with: gifFrames, timePerFrame: 0.4)
        gifNode.run(SKAction.repeatForever(animateAction))
    }

    func transitionToPlayScene() {
        let playScene = PlayScene(size: self.size)
        playScene.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        playScene.scaleMode = .aspectFill
        let transition = SKTransition.fade(withDuration: 1.0)
        self.view?.presentScene(playScene, transition: transition)
    }
}
