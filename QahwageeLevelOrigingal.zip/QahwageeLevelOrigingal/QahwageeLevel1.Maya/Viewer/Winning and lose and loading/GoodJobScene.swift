import Foundation
import SpriteKit

class GoodJobScene: SKScene {
    var gifFrames: [SKTexture] = []
    var gifNode: SKSpriteNode!

    override func didMove(to view: SKView) {
        backgroundColor = SKColor.black
        loadGifFrames()
        if !gifFrames.isEmpty {
            displayGif()
        }
        setupRetryButton()

        // تأخير تشغيل الصوت
        let delayAction = SKAction.wait(forDuration: 0.9) // تأخير الصوت لمدة 1 ثانية (يمكنك تعديلها كما تريد)
        let playSoundAction = SKAction.run {
            self.playSound()
        }
        let sequence = SKAction.sequence([delayAction, playSoundAction])
        self.run(sequence)
        
        // الانتقال إلى مشهد المستويات بعد فترة زمنية
        let wait = SKAction.wait(forDuration: 4.0)
        let transitionToLevels = SKAction.run {
            let levelsScene = Levels(size: self.size)
            levelsScene.scaleMode = .aspectFill
            let transition = SKTransition.fade(withDuration: 1.0)
            self.view?.presentScene(levelsScene, transition: transition)
        }
        self.run(SKAction.sequence([wait, transitionToLevels]))
    }

    func loadGifFrames() {
        gifFrames.removeAll()
        for i in 1...15 { // تأكد من تغيير العدد ليطابق عدد إطارات الـ GIF لديك
            let imageName = "winning screen gif-\(i)" // تأكد من تسمية الصور بشكل صحيح
            let texture = SKTexture(imageNamed: imageName)
            if texture.size() != CGSize.zero { // تأكد من أن الصورة تم تحميلها بنجاح
                gifFrames.append(texture)
            } else {
                print("Failed to load image named \(imageName)")
            }
        }
    }

    func displayGif() {
        guard let firstFrame = gifFrames.first else { return }
        gifNode = SKSpriteNode(texture: firstFrame)
        gifNode.position = CGPoint(x: frame.midX, y: frame.midY)
        
        // ضبط حجم الصورة لتتناسب مع نسبة العرض إلى الارتفاع للشاشة
        let aspectRatio = firstFrame.size().width / firstFrame.size().height
        var newWidth: CGFloat
        var newHeight: CGFloat
        
        // ضبط العرض والارتفاع حسب نسبة العرض إلى الارتفاع للشاشة
        if frame.width / frame.height > aspectRatio {
            newHeight = frame.height
            newWidth = newHeight * aspectRatio
        } else {
            newWidth = frame.width
            newHeight = newWidth / aspectRatio
        }
        
        gifNode.size = CGSize(width: newWidth, height: newHeight)
        
        addChild(gifNode)
        let animateAction = SKAction.animate(with: gifFrames, timePerFrame: 0.28) // ضبط سرعة الإطارات هنا (0.4 ثانية لكل إطار لتبطيئها)
        gifNode.run(SKAction.repeatForever(animateAction))
    }

    func setupRetryButton() {
        let retryButton = SKLabelNode(text: "")
        retryButton.fontSize = 45
        retryButton.fontColor = SKColor.white
        retryButton.position = CGPoint(x: frame.midX, y: frame.midY - 200)
        retryButton.name = "retryButton"
        addChild(retryButton)
    }

    func playSound() {
        let soundAction = SKAction.playSoundFileNamed("Coins.mp3", waitForCompletion: false)
        self.run(soundAction)
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        let location = touch.location(in: self)
        let nodesArray = nodes(at: location)

        if nodesArray.first?.name == "retryButton" {
            guard let view = self.view else { return }
            let transition = SKTransition.flipHorizontal(withDuration: 0.5)
            let levelsScene = Levels(size: self.size)
            gifNode.removeFromParent() // إزالة الصور المتحركة عند الانتقال إلى المشهد التالي
            view.presentScene(levelsScene, transition: transition)
        }
    }
}
