import Foundation
import SpriteKit

class GameOverScene: SKScene {
    var gifFrames: [SKTexture] = []
    var gifNode: SKSpriteNode!

    override func didMove(to view: SKView) {
        backgroundColor = SKColor.black
        loadGifFrames()
        if !gifFrames.isEmpty {
            displayGif()
        }
        setupRetryButton()
        playSound()

        // الانتقال إلى مشهد المستويات بعد فترة زمنية
        let wait = SKAction.wait(forDuration: 3.0)
        let transitionToLevels = SKAction.run {
            let levelsScene = Levels(size: self.size)
            levelsScene.scaleMode = .aspectFill
            let transition = SKTransition.fade(withDuration: 1.0)
            self.view?.presentScene(levelsScene, transition: transition)
        }
        self.run(SKAction.sequence([wait, transitionToLevels]))
    }

    func playSound() {
        let soundAction = SKAction.playSoundFileNamed("GameOver.mp3", waitForCompletion: false)
        self.run(soundAction)
    }

    func loadGifFrames() {
        gifFrames.removeAll()
        for i in 1...16 { // تأكد من تغيير العدد ليطابق عدد إطارات الـ GIF لديك
            let imageName = "frame\(i)"
            let texture = SKTexture(imageNamed: imageName)
            if texture.size() != CGSize.zero { // تأكد من أن الصورة تم تحميلها بنجاح
                gifFrames.append(texture)
            } else {
                print("Failed to load image named \(imageName)")
            }
        }
    }

    func displayGif() {
        guard let firstFrame = gifFrames.first else { return }
        gifNode = SKSpriteNode(texture: firstFrame)
        gifNode.position = CGPoint(x: frame.midX, y: frame.midY)
        gifNode.size = CGSize(width: frame.width, height: frame.height) // ضبط حجم الصورة لتملأ الشاشة
        addChild(gifNode)
        let animateAction = SKAction.animate(with: gifFrames, timePerFrame: 0.21) // ضبط سرعة الإطارات هنا (0.2 ثانية لكل إطار)
        gifNode.run(SKAction.repeatForever(animateAction))
    }

    func setupRetryButton() {
        let retryButton = SKLabelNode(text: "")
        retryButton.fontSize = 45
        retryButton.fontColor = SKColor.white
        retryButton.position = CGPoint(x: frame.midX, y: frame.midY - 200)
        retryButton.name = "retryButton"
        addChild(retryButton)
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        let location = touch.location(in: self)
        let nodesArray = nodes(at: location)

        if nodesArray.first?.name == "retryButton" {
            guard let view = self.view else { return }
            let transition = SKTransition.flipHorizontal(withDuration: 0.5)
            let levelsScene = Levels(size: self.size)
            gifNode.removeFromParent() // إزالة الصور المتحركة عند الانتقال إلى المشهد التالي
            view.presentScene(levelsScene, transition: transition)
        }
    }
}
