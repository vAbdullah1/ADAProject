//
//  PlayScene3.swift
//  QahwageeLevel1
//
//  Created by rana on 22/02/1446 AH.
//

import Foundation

import SpriteKit
import GameplayKit

//level 2
class PlayScene3: SKScene {
    

    var fireAnimationAction: SKAction?
    var Qahwagee: QahwageeMovement!
    var guests: [GuestMovement] = []
    var dallah: Dallah!
    var timerManager: TimerManager!
    var timerLabel: SKLabelNode!
    var guestBars: [GuestBar]=[]
    var guestBar:GuestBar!
    var cupArray:[Cup]=[]
    var guestCup:Cup!
    var cupCounter:CupCounter!
    var Sheikh: GuestMovement!
    var Sheikh2: GuestMovement!
    var sheikhDrinkTwice: Int = 0
    
    override func didMove(to view: SKView) {
        
        //Background
        //**Background quilty and sound and buttons
        setupBackground()
        setupFireAnimation()
        setUpDallahs()
        //  playFireSound()
        //buttons
        
        //Characters
        setupCharacterMovement()
        setupGuests()//guest and sheikh
        startGuestMovement(delayTime: 3.0)
        
        //Progress Bar & Timer
        setupProgressBar()
        setupTimer()
        // Setup cup count labels
        setupCoffeeCountLabel()
        setUpCoffeeCups()
        // Example: Transition back to GameScene after 5 seconds
        //                  let wait = SKAction.wait(forDuration: 5.0)
        //                  let transitionAction = SKAction.run {
        //                      self.transitionToGameScene()
        //                  }
        //                  self.run(SKAction.sequence([wait, transitionAction]))
        
    }
    

    //Constantly calls the functions
    override func update(_ currentTime: TimeInterval) {
        setGuestBarForAll()
        
        for bar in guestBars {
           if bar.hasBarReachedSeventyPercent()
            {
               delay(2.0)
               {
                   //bar.allowDrinking=false
                   self.didReachSeventyPercent(for: bar)
               }
               
                //break // Exit the loop if a bar is found at the same position
            }
        }
    }
    
    //Make a delay
    func delay(_ delay: TimeInterval, closure: @escaping () -> Void) {
        DispatchQueue.main.asyncAfter(deadline: .now() + delay, execute: closure)
    }
    
    
    //Characters Functions
    
    //Qahwagee
    func setupCharacterMovement() {
        
        //  let initialPosition = CGPoint(x: -423.756, y: -17)
        let initialPosition = CGPoint(x: 640, y: -160)
        Qahwagee = QahwageeMovement(initialPosition: initialPosition)
        Qahwagee.addCharacter(to: self)
    }
    
    //Guest
    
    func setupGuests() {
        let guestArea = [
//            "Area6",//path1
  //          "Area7",//path2
            "Area5",//path3
            "Area8",//path4
            
            //correct
            "Area9",//path5
            "Area4",//path6
            
            //correct
            "Area10",//path7
            "Area3",//path8
//
//            //correct
             "Area11",//path9
             "Area2",//path10
             "Area12",//path11
             "Area1"//path12
        ]
        
        Sheikh = GuestMovement(path: "path1", guestName: "guest1", guestArea: "Area6", GuestType: "sheikh")
        guests.append(Sheikh)
        Sheikh2 = GuestMovement(path: "path2", guestName: "guest2", guestArea: "Area7", GuestType: "sheikh")
        guests.append(Sheikh2)
        
        for (index, areaName) in guestArea.enumerated() {
            let adjustedIndex = index + 3
            let guest = GuestMovement(path: "path\(adjustedIndex)", guestName: "guest\(adjustedIndex)", guestArea: areaName, GuestType: "guest")
            
            guests.append(guest)
        }

    }
    

    
    func setUpCoffeeCups() {
        for guest in guests {
            // Access the paths dictionary from the guest
            let guestPaths = guest.paths
            
            for (pathName, pathPoints) in guestPaths {
                // Check if the guest's path matches the current path
                if guest.guestPath == pathName {
                   // if pathPoints.count > 1 {
                        // Get the x position of the second point in the path
                        let xPosition = pathPoints[1].x
                        
                        // Initialize the guest's cup with the x position
                        guestCup = Cup(xPosition: xPosition) // Assuming CupNode is your cup class
                         
                        cupArray.append(guestCup)
                        // Optionally, add the cup to the scene if needed
                      

                }
            }
        }
    }

    
    func startGuestMovement(delayTime: TimeInterval) {
 
        
        for (index, guest) in guests.enumerated() {
            DispatchQueue.main.asyncAfter(deadline: .now() + delayTime * TimeInterval(index)) {
                guest.startMovement(scene: self)
            }
        }
    }
    
    
    //Guest Progress Bar
    

    
    func didReachSeventyPercent(for guestBar: GuestBar)
    {
      
        
        
        for guest in guests
        {
            for cup in cupArray
            {
                if guest.character.position.x == guestBar.position.x && guest.hasDrink == false &&
                    guest.character.position.x == cup.position.x
                {
                    // if guest.guestType=="guest" || guest.guestType != "guest" && sheikhDrinkTwice<2
                    //  {
                    
                    guestBar.removeFromParent()
                    
                    if guest.character.hasActions() == false
                    {
                        
                        guest.exitMovement()
                        self.cupCounter.dropCupCount()
                        cup.drop(in: self)
                        
                        if let index = cupArray.firstIndex(of: cup) 
                        {
                        cupArray.remove(at: index)
                        }
                        break
                    }
                    
                    //  }
                    
                }
            }
           
        }
   }
    
    func setupGuestBar(at x: CGFloat, guest: GuestMovement)
    {

            let xSettingPoint = x
            let ySettingPoint = 363.00 + 10
                   
            let guestBar = GuestBar(xPosition: xSettingPoint, yPosition: ySettingPoint)
                   
            print(xSettingPoint)
        
            guestBar.position = CGPoint( x: xSettingPoint, y: ySettingPoint )// Position each bar with some spacing
       
       
            guestBar.zPosition=10
            addChild(guestBar)
            guestBars.append(guestBar)
        
        var time = 12.0
        if guest.guestType != "guest"
        {
            time = 9.0
        }
            guestBar.startProgressAnimation(duration: time) // Adjust the duration if needed 10

    }
    
    
    func setGuestBarForAll() {
        for guest in guests {
            if guest.character.position.y == 254.00 {
                var shouldAddBar = true
                
                // Check if a bar already exists at the guest's x position
                for bar in guestBars {
                    if bar.position.x == guest.character.position.x {
                        shouldAddBar = false
                        break // Exit the loop if a bar is found at the same position
                    }
                }
                
                // Only add the bar if no existing bar is found at the same position
                if shouldAddBar {
                    setupGuestBar(at: guest.character.position.x,guest: guest)
                }
            }
        }
    }

    // cup counter
    func setupCoffeeCountLabel() {
           // Initialize CupCounter with maxCups and the scene
           cupCounter = CupCounter(maxCups: 3, scene: self)
       }
    
    
    //Timer function
    
    private func setupTimer() {
        // Initialize the timer label and position it
        timerLabel = SKLabelNode(fontNamed: "PressStart2P-Regular")
        timerLabel.position = CGPoint(x: self.frame.midX - 1090, y: self.frame.midY + 418)
        
        // Initialize the TimerManager and start the timer
        timerManager = TimerManager(initialTime: 45, label: timerLabel, scene: self)
        timerManager.startTimer()
    }
    
    
    
    //Dallah progress bar
    func setupProgressBar() {
        dallah = Dallah(maxSlots: 5, scene: self) // Initialize the Dallah with the desired number of slots and pass the scene
    }
    
    
    //Touch Actions

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        let location = touch.location(in: self)
        
        // Move the character based on touch
        Qahwagee.moveCharacter(to: location, duration: 2.0)
        
        //Dallah Progress Bar
        if Qahwagee.isLocationFire(location: location) {
            dallah.refillProgressBar(delay: 2.0)
        }
        else if Qahwagee.isLocationChairs(location: location) {
            let result = findGuestAndGuestBar(at: location) // return the guest(that is next to Qahwagee and the bar of the guest
            
            if let guest = result.guest, let guestBar = result.guestBar {
                if  !guestBar.hasBarReachedSeventyPercent() && !self.dallah.isDallahEmpty()
                {
                    // Initial delay before starting the sequence of actions
                    delay(2.4) {
                        self.dallah.decreaseProgressBar(delay: 0)
                        
                        if guest.character.hasActions() == false {
                            guestBar.removeFromParent()
                            
                            // Perform the drinking action
                            guest.drinkingCharacter()
        
                              self.delay(4) {
                                    guest.setCharacter()
                                    
                                    // Delay before exiting
                                    self.delay(2) {
                                        guest.exitMovement2()
                                    }
                                }
                            
                            
                            // Delay before setting the character
                           
                        }
                    }
                }
            }
    }
        



    }
    
    
    //Touch related functions
    
    
    
    func isGuestsSitting(guest :GuestMovement) -> Bool {
        for guest in guests {
            if guest.character.position.y == 254.00 {
                
                return true
            }
        }
        return false
    }
    
    
    func isQahwageeNextToGuest(guest: GuestMovement) -> Bool {
        if ( Qahwagee.QahwageeArea == guest.guestArea )
            {
                return true
            }
        
        return false
    }
    
    func findGuestAndGuestBar(at location: CGPoint) -> (guest: GuestMovement?, guestBar: GuestBar?) {
        for guest in guests {
            if isGuestsSitting(guest: guest) && isQahwageeNextToGuest(guest: guest) {
                for guestBar in guestBars {
                    if guest.character.position.x == guestBar.position.x {
                        return (guest, guestBar)
                    }
                }
            }
        }
        return (nil, nil)
    }


    
    
    

    
   
    
  

    
    
    
    
    
 
    
    //Background Functions
    
    func transitionToGameScene() {
        let gameScene = GameScene(size: self.size)
        gameScene.scaleMode = .aspectFill
        
        // Define the transition style
        let transition = SKTransition.flipHorizontal(withDuration: 1.0)
        
        // Present the GameScene with transition
        self.view?.presentScene(gameScene, transition: transition)
    }
    
    
    private func setupBackground() {
        let background = SKSpriteNode(imageNamed: "gamescreen")
        background.position = CGPoint(x: 0, y: 0)
        background.zPosition = -1  // Behind other elements in PlayScene
        background.size = CGSize(width: frame.width, height: frame.height)
        background.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        addChild(background)
    }
    
    private func setupButtons() {
        // Example button setup
        let button = SKSpriteNode(imageNamed: "buttonImage") // Replace with your button image name
        button.position = CGPoint(x: self.size.width / 2, y: self.size.height / 4)
        button.name = "button"
        button.zPosition = 1
        addChild(button)
        
        // Add more buttons here as needed
    }
    
    private func setupFireAnimation() {
        // Load the textures for the fire animation
        var textures: [SKTexture] = []
        for i in 29...32 {
            let textureName = "\(i).png"
            let texture = SKTexture(imageNamed: textureName)
            textures.append(texture)
        }
        // Add the reverse frames to create a smooth loop
        textures.append(textures[2])
        textures.append(textures[1])
        
        // Create an SKAction to animate the textures
        let fireAnimationAction = SKAction.animate(with: textures, timePerFrame: 0.1)
        
        // Create an SKSpriteNode to display the animation
        let fireNode = SKSpriteNode(texture: textures.first)
        fireNode.position = CGPoint(x: 3.624 / 2, y: -410.936) // Specify the position here
        fireNode.size = CGSize(width: 340.491, height: 202.14)
        fireNode.zPosition = 2 // Ensure the fire animation appears above the background but below other UI elements
        
        // Run the animation on the node
        fireNode.run(SKAction.repeatForever(fireAnimationAction))
        
        // Add the node to the scene
        addChild(fireNode)
    }
    
    func setUpDallahs()
    {
        let Shbak = SKSpriteNode(imageNamed: "Shbk")

        Shbak.position = CGPoint(x:10.358, y: -402.02)
        Shbak.zPosition = 3
        Shbak.size = CGSize(width: 353.958, height: 184.309)// Makes the background fill the entire scene
        Shbak.anchorPoint=CGPoint(x: 0.5 , y: 0.5)
        addChild(Shbak)
        
        // Define the common size for all Dallahs
        let dallahSmallSize = CGSize(width: 79.663, height: 63.986)
        
        // Define the positions for the three Dallah instances
        let dallahSmallPositions = [
            CGPoint(x: -84.462, y: -391.993),
            CGPoint(x: -13.532, y: -391.993),
            CGPoint(x: 61.662, y: -391.993)
        ]
        
        // Loop through the positions and add Dallahs
        for position in dallahSmallPositions {
            let dallah = SKSpriteNode(imageNamed: "Dallah")
            dallah.position = position
            dallah.zPosition = 5
            dallah.size = dallahSmallSize
            dallah.anchorPoint = CGPoint(x: 0.5, y: 0.5)
            addChild(dallah)
        }
        
        // Define the common size for all Dallahs
        let dallahBigSize = CGSize(width: 88.899, height: 75.835)
        
        // Define the positions for the three Dallah instances
        let dallahBigPositions = [
            CGPoint(x: -55.394, y: -406.248),
            CGPoint(x: 23.624, y: -406.248),
            CGPoint(x: 104.77, y: -406.248)
        ]
        
        // Loop through the positions and add Dallahs
        for position in dallahBigPositions {
            let dallah = SKSpriteNode(imageNamed: "Dallah")
            dallah.position = position
            dallah.zPosition = 6
            dallah.size = dallahBigSize
            dallah.anchorPoint = CGPoint(x: 0.5, y: 0.5)
            addChild(dallah)
        }
        
    }
    
    private func playFireSound() {
        let playSoundAction = SKAction.playSoundFileNamed("fireSound.mp3", waitForCompletion: false)
        run(SKAction.repeatForever(playSoundAction))
    }
    
    
    
}
    
    
    


    



