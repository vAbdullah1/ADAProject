import SpriteKit

class QahwageeMovement {
    
    var character: SKSpriteNode!
    var moveUpFrames: [SKTexture] = []
    var moveDownFrames: [SKTexture] = []
    var moveLeftFrames: [SKTexture] = []
    var moveRightFrames: [SKTexture] = []

    var QahwageeArea:String
    
    let chairAreas: [String: [CGPoint]] = [
        "Area1": [CGPoint(x: -940, y: 300), CGPoint(x: -815, y: 150)],
        "Area2": [CGPoint(x: -815, y: 300), CGPoint(x: -615, y: 150)],
        
        "Area3":[CGPoint(x: -610, y: 300), CGPoint(x: -490, y: 150)],
        "Area4":[CGPoint(x: -490, y: 300), CGPoint(x: -370, y: 150)],
        
        "Area5":[CGPoint(x: -280, y: 300), CGPoint(x: -160, y: 150)],
        "Area6":[CGPoint(x: -160, y: 300), CGPoint(x: -40, y: 150)],
        
        "Area7":[CGPoint(x: 40, y: 300), CGPoint(x: 165, y: 150)],
        "Area8":[CGPoint(x: 165, y: 300), CGPoint(x: 285, y: 150)],
        
        
        "Area9":[CGPoint(x: 370, y: 300), CGPoint(x: 490, y: 150)],
        "Area10":[CGPoint(x: 490, y: 300), CGPoint(x: 615, y: 150)],
        
        "Area11":[CGPoint(x: 695, y: 300), CGPoint(x: 820, y: 150)],
        "Area12":[CGPoint(x:820, y: 300), CGPoint(x: 940, y: 150)]
    ]
    
    
    let fireplace: [CGPoint] = [
        CGPoint(x: -180.0 , y: -340),
        CGPoint(x: 200, y: -550)
    ]
    var locationName = "none"
    
    init(initialPosition: CGPoint) {
        // Load the textures for each direction
        for i in 1...12 {
            let texture = SKTexture(imageNamed: "Mov\(i)")
            if i < 4 {
                if i != 2
                {moveUpFrames.append(texture)
                }
            } else if i < 7 {
                moveRightFrames.append(texture)
            } else if i < 10 {
                if i != 8
                {
                    moveDownFrames.append(texture)
                }
                
            } else {
                moveLeftFrames.append(texture)
            }
        }
        // Start with the first frame of "down" direction as the initial character texture
        character = SKSpriteNode(texture: SKTexture(imageNamed: "Mov8"))
        character.size=CGSize(width: 97.828, height: 188.606)
        character.position = initialPosition
        self.QahwageeArea = "none"
    }
    
    func addCharacter(to scene: SKScene) {
        // Add the character sprite to the scene
        character.zPosition = 3
        
        character.size=CGSize(width: 62.774, height: 167.783)
        scene.addChild(character)
    }

    
    
    func moveCharacter(to location: CGPoint, duration: TimeInterval) {
    
        
        if isLocationAllowed(location: location) {
            print(character.position.y)
            
            let adjustedLocation = borderLocation(location: location)
            
            if character.position.y == -387.00 {
                turn(to: location, adjustedLocation: adjustedLocation, duration: duration)
            } else {
                // Directly move to the touched location if the character is not in the special start position
                moveToAdjustedLocation(adjustedLocation, duration: duration)
            }
            
        }
        else
        {
            print("not allowed")
        }
           
    }

    func turn(to location: CGPoint, adjustedLocation: CGPoint, duration: TimeInterval) {
        // Determine which special position to move to based on the x-coordinate
        
        let specialRightPosition = CGPoint(x: 220.0, y: -257.273)
        let specialLeftPosition = CGPoint(x: -220.0, y: -257.273)
        if QahwageeArea=="Area7" || location.x < 0 && character.position.x>0 {
            // First move to the special right position
            moveToAdjustedLocation(specialRightPosition, duration: 0.5)
        } else 
        if QahwageeArea=="Area6" || location.x >= 0 && character.position.x<0 {
            // First move to the special left position
            moveToAdjustedLocation(specialLeftPosition, duration: 0.5)
        }
        
        // Then move to the final touched location after a delay
        let delayAction = SKAction.wait(forDuration: 0.50)
        let moveToFinalLocation = SKAction.run {
            self.moveToAdjustedLocation(adjustedLocation, duration: duration)
        }
        
        let sequence = SKAction.sequence([delayAction, moveToFinalLocation])
        character.run(sequence)
    }

    
    
    // Function to calculate the adjusted location based on the boundaries
    func borderLocation(location: CGPoint) -> CGPoint {
        var adjustedLocation = location
        
        if(locationName=="fireplace")
        {
            self.QahwageeArea="fireplace"
            
            if character.position.x>=0
            {
                adjustedLocation.x = 220.0
            }
            else
            if character.position.x<0
            {
                adjustedLocation.x = -220.0
            }
            
            adjustedLocation.y = -387.00
            return adjustedLocation
        }
        else if(locationName=="Area1")
        {
            adjustedLocation.x = -832.949
            self.QahwageeArea="Area1"
            
        }
        else if(locationName=="Area2")
        {
            adjustedLocation.x = -720
            self.QahwageeArea="Area2"
            
        }
        else if (locationName=="Area3")
        {
            adjustedLocation.x = -498.258
            self.QahwageeArea="Area3"
        }
        else if (locationName=="Area4")
        {
            adjustedLocation.x = -378.031
            self.QahwageeArea="Area4"
        }
        else if (locationName=="Area5")
        {
            adjustedLocation.x = -165.296
            self.QahwageeArea="Area5"
        }
        else if (locationName=="Area6")
        {
            adjustedLocation.x = -46.25
            self.QahwageeArea="Area6"
        }
        else if (locationName=="Area7")
        {
            adjustedLocation.x = 165.368
            self.QahwageeArea="Area7"
        }
        else if (locationName=="Area8")
        {
            adjustedLocation.x = 283.304
            self.QahwageeArea="Area8"
        }
        else if (locationName=="Area9")
        {
            adjustedLocation.x = 491.936
            self.QahwageeArea="Area9"
        }
        else if (locationName=="Area10")
        {
            adjustedLocation.x = 600
            self.QahwageeArea="Area10"
        }
        else if (locationName=="Area11")
        {
            adjustedLocation.x = 818.031
            self.QahwageeArea="Area11"
        }
        else if (locationName=="Area12")
        {
            adjustedLocation.x = 941.969
            self.QahwageeArea="Area12"
        }
        
        adjustedLocation.y = 192.00
        return adjustedLocation
        
    }
    
    
    func isLocationAllowed(location: CGPoint) -> Bool {
        // Define the target area for the fireplace
        let targetAreaXRange: ClosedRange<CGFloat> = fireplace[0].x ... fireplace[1].x
        let targetAreaYRange: ClosedRange<CGFloat> = fireplace[1].y ... fireplace[0].y
        
        // Check if the location is within the fireplace area
        if targetAreaXRange.contains(location.x) && targetAreaYRange.contains(location.y) {
            
            locationName = "fireplace"
            return true
        }
        
        // Check if the location is within any of the chair areas
        for (area, chairPositions) in chairAreas {
            
            let chairXRange: ClosedRange<CGFloat> = chairPositions[0].x ... chairPositions[1].x
            let chairYRange: ClosedRange<CGFloat> = chairPositions[1].y ... chairPositions[0].y
            
            if chairXRange.contains(location.x) && chairYRange.contains(location.y) {
                locationName=area
                return true
            }
        }
        
        // If the location is not in any allowed area, return false
        return false
    }
    
    func isLocationFire(location: CGPoint) -> Bool {
        // Define the target area for the fireplace
        let targetAreaXRange: ClosedRange<CGFloat> = fireplace[0].x ... fireplace[1].x
        let targetAreaYRange: ClosedRange<CGFloat> = fireplace[1].y ... fireplace[0].y
        
        // Check if the location is within the fireplace area
        if targetAreaXRange.contains(location.x) && targetAreaYRange.contains(location.y) {
            
            locationName = "fireplace"
            return true
        }
        
        // If the location is not in any allowed area, return false
        return false
    }
    
    func isLocationChairs(location: CGPoint) -> Bool {
   
        // Check if the location is within any of the chair areas
        for (area, chairPositions) in chairAreas {
            
            let chairXRange: ClosedRange<CGFloat> = chairPositions[0].x ... chairPositions[1].x
            let chairYRange: ClosedRange<CGFloat> = chairPositions[1].y ... chairPositions[0].y
            
            if chairXRange.contains(location.x) && chairYRange.contains(location.y) {
                locationName=area
                return true
            }
        }
        
        
        // If the location is not in any allowed area, return false
        return false
    }
    
    // Function to move the character to the adjusted location
    func moveToAdjustedLocation(_ adjustedLocation: CGPoint, duration: TimeInterval) {
        // Stop any ongoing movement actions
        character.removeAction(forKey: "animate")

        var actions: [SKAction] = []
        
        let dx = adjustedLocation.x - character.position.x
        let dy = adjustedLocation.y - character.position.y
            if abs(dx) > 5 {
                actions.append(createMovementAction(dx: dx, dy: dy, direction: .horizontal, duration: duration))
                
            }
            
            if abs(dy) > 5 {
                actions.append(createMovementAction(dx: dx, dy: dy, direction: .vertical, duration: duration))
                
            }
            
            // Add final action to ensure the character stops at the correct final frame
            
            var stopAnimation = createStopAnimation()
            
            actions.append(stopAnimation)
            
            let sequence = SKAction.sequence(actions)
            character.run(sequence, withKey: "animate")
        }
        
        
        func createStopAnimation() -> SKAction {
            return SKAction.run {
                
                if self.locationName == "fireplace" {
                    
                    // Handle fireplace-specific logic
                    if self.character.position.x >= 0 {
                        self.character.texture = self.moveLeftFrames[1]
                    } else {
                        self.character.texture = self.moveRightFrames[1]
                    }
                } else {
                    // Use the default stop animation
                    self.character.texture = self.moveLeftFrames[1]
                }
            }
        }

        // Function to create the movement action
        func createMovementAction(dx: CGFloat, dy: CGFloat, direction: MovementDirection, duration: TimeInterval) -> SKAction {
            var frames: [SKTexture] = []
            
            var movementAction: SKAction
            
            switch direction {
            case .horizontal:
                if dx > 0 {
                    frames = moveRightFrames
                    
                } else {
                    frames = moveLeftFrames
                    
                }
                movementAction = SKAction.moveTo(x: character.position.x + dx, duration: duration * abs(dx) / (abs(dx) + abs(dy)))
            case .vertical:
                if dy > 0 {
                    frames = moveUpFrames
                    
                } else {
                    frames = moveDownFrames
                    
                }
                movementAction = SKAction.moveTo(y: character.position.y + dy, duration: duration * abs(dy) / (abs(dx) + abs(dy)))
            }
            
            let animateAction = SKAction.animate(with: frames, timePerFrame: 0.1)
            let repeatAnimation = SKAction.repeat(animateAction, count: Int(movementAction.duration / (0.1 * Double(frames.count))))
            let groupAction = SKAction.group([movementAction, repeatAnimation])
            
            return groupAction
        }
        
        // Enum to represent the movement direction
        enum MovementDirection {
            case horizontal
            case vertical
        }
  
    }

