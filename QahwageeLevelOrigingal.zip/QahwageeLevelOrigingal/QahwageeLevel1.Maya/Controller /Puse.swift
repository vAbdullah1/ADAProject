import SpriteKit
import AVFoundation

class Puse: SKNode {
    
    // إنشاء العقد باستخدام الأسماء الجديدة
    private let pauseButton = SKSpriteNode(imageNamed: "puse")
    private let settingBox = SKSpriteNode(imageNamed: "settingbox")
    private let musicButton = SKSpriteNode(imageNamed: "musicbotton")
    private let soundButton = SKSpriteNode(imageNamed: "soundbotton")
    private let exitButton = SKSpriteNode(imageNamed: "bottonexitt")
    private let xButton = SKSpriteNode(imageNamed: "xbotton")
    
    private var musicPlayer: AVAudioPlayer?  // للإشارة إلى مشغل الموسيقى
    private var fireSoundPlayer: AVAudioPlayer?  // للإشارة إلى مشغل صوت النار
    private var isGamePaused = false  // للإشارة إلى حالة اللعبة

    override init() {
        super.init()
//        musicPlayer =
        isUserInteractionEnabled = true
        
        // إعداد زر الإيقاف المؤقت
        pauseButton.position = CGPoint(x: 994.277, y: 489.653)  // مثال على الموقع، يمكن تعديله حسب الحاجة
        pauseButton.size = CGSize(width: 200, height: 200) // تأكد من ظهور الزر بوضوح
        pauseButton.zPosition = 10  // تأكد من أنه فوق بقية العناصر
        addChild(pauseButton)
        
        // إعداد قائمة الإعدادات والأزرار بداخلها، في البداية تكون مخفية
        settingBox.position = CGPoint(x: 0, y: 0)
        settingBox.size = CGSize(width: 450, height: 450)  // تحديد حجم settingBox
        settingBox.zPosition = 2
        settingBox.isHidden = true
        addChild(settingBox)
        
        // إعداد الأزرار بداخل settingBox
        musicButton.position = CGPoint(x: 0, y: 102.788)  // ضبط مواقع الأزرار بما يتناسب مع حجم settingBox
        musicButton.size = CGSize(width: 350, height: 100)
        musicButton.zPosition = 3
        settingBox.addChild(musicButton)
        
        soundButton.position = CGPoint(x: 0, y: 0)
        soundButton.size = CGSize(width: 350, height: 100)
        soundButton.zPosition = 3
        settingBox.addChild(soundButton)
        
        exitButton.position = CGPoint(x: 0, y: -103.895)
        exitButton.size = CGSize(width: 350, height: 100)
        exitButton.zPosition = 3
        settingBox.addChild(exitButton)
        
        // إعداد زر xButton في أعلى يمين settingBox
        xButton.position = CGPoint(x: settingBox.size.width / 2 - 25, y: settingBox.size.height / 2 - 25)
        xButton.size = CGSize(width: 50, height: 50)
        xButton.zPosition = 4
        settingBox.addChild(xButton)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    func setupAudioPlayer(avAudioPlayer: AVAudioPlayer) {
        self.musicPlayer = avAudioPlayer
    }
    
    func setAudioPlayers(musicPlayer: AVAudioPlayer?, fireSoundPlayer: AVAudioPlayer?) {
        self.musicPlayer = musicPlayer
        self.fireSoundPlayer = fireSoundPlayer
        
        if musicPlayer != nil {
            print("Music player set successfully")
        } else {
            print("Music player is nil when setting")
        }
        
        if fireSoundPlayer != nil {
            print("Fire sound player set successfully")
        } else {
            print("Fire sound player is nil when setting")
        }
    }
    
    func handleTouch(at location: CGPoint) {
        if pauseButton.contains(location) {
            togglePause()
            toggleSettingBox()
            print("Pause button tapped - setting box toggled and game paused/resumed")
        }
        
        if !settingBox.isHidden {
            if xButton.contains(location) {
                settingBox.isHidden = true
                print("X button tapped - setting box hidden")
            }
            else if musicButton.contains(location) {
                toggleMusic()
                print("Music button tapped")
            }
            else if soundButton.contains(location) {
                toggleFireSound()
                print("Sound button tapped")
            }
            else if exitButton.contains(location) {
                // الانتقال إلى مشهد Levels عند الضغط على زر الخروج
                print("Exit button tapped")
                exitToLevels()  // الانتقال إلى كلاس Levels
            }
        }
    }
    
    private func toggleSettingBox() {
        settingBox.isHidden.toggle()
    }
    
    private func togglePause() {
        if let scene = self.scene {
            scene.isPaused = !scene.isPaused
            isGamePaused = scene.isPaused
        }
    }
    
    private func toggleMusic() {
        guard let player = musicPlayer else {
            print("Music player is nil")
            return
        }
        if player.isPlaying {
            player.pause()
            print("Music paused")
        } else {
            player.play()
            print("Music playing")
        }
    }
    
    private func toggleFireSound() {
        guard let player = fireSoundPlayer else {
            print("Fire sound player is nil")
            return
        }
        if player.isPlaying {
            player.pause()
            print("Fire sound paused")
        } else {
            player.play()
            print("Fire sound playing")
        }
    }
    
    private func exitToLevels() {
        guard let scene = self.scene else { return }
        let levelsScene = Levels(size: scene.size)
        levelsScene.scaleMode = .aspectFill
        let transition = SKTransition.fade(withDuration: 1.0)
        scene.view?.presentScene(levelsScene, transition: transition)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        if let firstLocation = touches.first?.location(in: self) {
            handleTouch(at: firstLocation)
        }
    }
}
