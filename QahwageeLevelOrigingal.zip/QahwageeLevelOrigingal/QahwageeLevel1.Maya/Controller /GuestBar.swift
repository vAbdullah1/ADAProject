import SpriteKit

class GuestBar: SKNode {
    
    private var progressBar1: SKShapeNode!
    private var initialImage: SKSpriteNode!
    private var halfImage: SKSpriteNode!
    private var seventyImage: SKSpriteNode!
    
    private var hasReachedSeventyPercent: Bool = false
    var allowDrinking: Bool = true
    
    init(xPosition: CGFloat, yPosition: CGFloat) {
        super.init()
        self.position = CGPoint(x: xPosition, y: yPosition)
        setupCircularProgressBar()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    func setupCircularProgressBar() {
        let backgroundCircleRadius: CGFloat = 40
        let backgroundCircle = SKShapeNode(circleOfRadius: backgroundCircleRadius)
        backgroundCircle.fillColor = .white
        backgroundCircle.zPosition = 0
        addChild(backgroundCircle)
        
        let outerRadius: CGFloat = 35
        let innerRadius: CGFloat = 20 / 2
        
        progressBar1 = SKShapeNode()
        let outerCirclePath = UIBezierPath(arcCenter: CGPoint.zero, radius: outerRadius, startAngle: 0, endAngle: CGFloat(2 * Double.pi), clockwise: true)
        let innerCirclePath = UIBezierPath(arcCenter: CGPoint.zero, radius: innerRadius, startAngle: 0, endAngle: CGFloat(2 * Double.pi), clockwise: true)
        outerCirclePath.append(innerCirclePath.reversing())
        progressBar1.path = outerCirclePath.cgPath
        progressBar1.fillColor = .clear
        progressBar1.strokeColor = .green
        progressBar1.lineWidth = 30
        progressBar1.zPosition = 2
        addChild(progressBar1)
        
        initialImage = SKSpriteNode(imageNamed: "InitialImage")
        initialImage.size = CGSize(width: 40, height: 40)
        initialImage.zPosition = 3
        addChild(initialImage)
        
        halfImage = SKSpriteNode(imageNamed: "HalfImage")
        halfImage.size = CGSize(width: 40, height: 40)
        halfImage.zPosition = 3
        halfImage.isHidden = true
        addChild(halfImage)
        
        seventyImage = SKSpriteNode(imageNamed: "SeventyImage")
        seventyImage.size = CGSize(width: 40, height: 40)
        seventyImage.zPosition = 3
        seventyImage.isHidden = true
        addChild(seventyImage)
    }
    
    func startProgressAnimation(duration: TimeInterval) {
        let progressAction = SKAction.customAction(withDuration: duration) { [weak self] node, elapsedTime in
            guard let strongSelf = self else { return }
            let percentage = CGFloat(elapsedTime) / CGFloat(duration)
            
            let progressRadius = (35 - 20) * percentage + 10
            
            let outerCirclePath = UIBezierPath(arcCenter: CGPoint.zero, radius: progressRadius, startAngle: 0, endAngle: CGFloat(2 * Double.pi), clockwise: true)
            let innerCirclePath = UIBezierPath(arcCenter: CGPoint.zero, radius: 20 / 2, startAngle: 0, endAngle: CGFloat(2 * Double.pi), clockwise: true)
            outerCirclePath.append(innerCirclePath.reversing())
            strongSelf.progressBar1.path = outerCirclePath.cgPath
            
            if percentage >= 0.9 && !strongSelf.hasReachedSeventyPercent {
                strongSelf.hasReachedSeventyPercent = true
                strongSelf.progressBar1.strokeColor = .red
                strongSelf.initialImage.isHidden = true
                strongSelf.halfImage.isHidden = true
                strongSelf.seventyImage.isHidden = false
            } else if percentage >= 0.5 {
                strongSelf.progressBar1.strokeColor = .orange
                strongSelf.initialImage.isHidden = true
                strongSelf.halfImage.isHidden = false
            }
        }
        progressBar1.run(progressAction)
    }
    
    // New function to check if the bar reached 70%
    func hasBarReachedSeventyPercent() -> Bool {
        return hasReachedSeventyPercent
    }
}
