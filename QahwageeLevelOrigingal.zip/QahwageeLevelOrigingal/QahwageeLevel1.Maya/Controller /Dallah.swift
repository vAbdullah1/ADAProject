//
//  Dallah.swift
//  QahwageeLevel1
//
//  Created by rana on 17/02/1446 AH.
//

import Foundation
import SpriteKit

class Dallah {
    private var progressBar = [SKSpriteNode]()
    private var slotsFilled: Int
    private let maxSlots: Int

    init(maxSlots: Int, scene: SKScene) {
        self.maxSlots = maxSlots
       self.slotsFilled = maxSlots
        setupProgressBar(in: scene)
    }

    private func setupProgressBar(in scene: SKScene) {
        let progressBarYPosition: CGFloat = 340.749 // Set Y position to 340.749
        let startXPosition: CGFloat = -1200 // Set X position to -1200

        // Calculate the total width of the progress bar
        let slotWidth: CGFloat = 35
        let slotSpacing: CGFloat = 40

        // Create the progress bar with the specified number of slots
        for i in 0..<maxSlots {
            let slot = SKSpriteNode(color: .green, size: CGSize(width: slotWidth, height: 30))
            slot.position = CGPoint(x: startXPosition + CGFloat(i) * slotSpacing + slotWidth / 2, y: progressBarYPosition)
            slot.zPosition = 1 // Ensure the slots are above the background
            progressBar.append(slot)
            scene.addChild(slot)
        }
    }


    func updateBarAppearance() {
            for i in 0..<maxSlots {
                if i < slotsFilled {
                    progressBar[i].color = .green
                } else {
                    progressBar[i].color = .clear
                }
            }
        }
    
    
    func decreaseProgressBar(delay: TimeInterval) {
        let waitAction = SKAction.wait(forDuration: delay)
        let decreaseAction = SKAction.run { [weak self] in
            guard let self = self else { return }
            if self.slotsFilled > 0 {
                self.slotsFilled -= 1
                self.progressBar[self.slotsFilled].color = .clear
                self.updateBarAppearance()
            }
        }
        // Run the actions in sequence: first the wait, then the decrease
        if let scene = progressBar.first?.scene {
            scene.run(SKAction.sequence([waitAction, decreaseAction]))
        }
    }

    
    
    func refillProgressBar(delay: TimeInterval) {
        let waitAction = SKAction.wait(forDuration: delay)
        let refillAction = SKAction.run { [weak self] in
            guard let self = self else { return }
            for slot in self.progressBar {
                slot.color = .green
            }
            self.slotsFilled = self.maxSlots
        }
        // Run the actions in sequence: first the wait, then the refill
        if let scene = progressBar.first?.scene {
            scene.run(SKAction.sequence([waitAction, refillAction]))
        }
    }
    
    
    
    func areSlotsFilled() -> Bool {
        return slotsFilled > 0
    }
    
    func isDallahEmpty() -> Bool {
        return slotsFilled == 0
    }
    
    
}
