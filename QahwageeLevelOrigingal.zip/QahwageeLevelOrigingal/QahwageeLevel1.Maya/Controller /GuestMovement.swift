import SpriteKit

class GuestMovement {
    
    var character: SKSpriteNode!
    var guestName: String
    var guestType:String
    var guestArea:String
    var guestPath:String
    var hasDrink:Bool = false
    var sheikhDrinkTwice: Int = 0
    
    
    let standSize = CGSize(width: 90, height: 200)
    let sitSize = CGSize(width: 90, height: 150)
    
   let initialPosition=CGPoint(x: 320, y: -687.411)

    let paths: [String: [CGPoint]] = [
         "path1":[CGPoint(x: -101.877, y: -155.296), CGPoint(x: -101.877, y: 254.00)],
         "path2":[CGPoint(x: 99.842, y: -155.296), CGPoint(x: 99.842, y: 254.00)],
         "path3":[CGPoint(x: -224.663, y: -155.296), CGPoint(x: -224.663, y: 254.00)],
         "path4":[CGPoint(x: 229.824, y: -155.296), CGPoint(x: 229.824, y: 254.00)],
         
         "path5":[CGPoint(x: 444.318, y: -155.296), CGPoint(x: 444.318, y: 254.00)],
         "path6":[CGPoint(x: -440.783, y: -155.296), CGPoint(x: -440.783, y: 254.00)],
         "path7":[CGPoint(x: 577.268, y: -155.296), CGPoint(x: 577.268, y: 254.00)],
         "path8":[CGPoint(x: -555.85, y: -155.296), CGPoint(x: -555.85, y: 254.00)],
         
        "path9":[CGPoint(x: 780.342, y: -155.296), CGPoint(x: 780.342, y: 254.00)],
        "path10":[CGPoint(x: -775.09, y: -155.296), CGPoint(x: -775.09, y: 254.00)],
        "path11":[CGPoint(x: 913.063, y: -155.296), CGPoint(x: 913.063, y: 254.00)],
        "path12":[CGPoint(x: -898.829, y: -155.296), CGPoint(x: -898.829, y: 254.00)]
        ]
    
   var moveUpFrames = [
        SKTexture(imageNamed: "guest1-1"),
        SKTexture(imageNamed: "guest1-2")
    ]
    
  var  moveLeftFrames = [
        SKTexture(imageNamed: "guest1-4"),
        SKTexture(imageNamed: "guest1-5")
    ]
    
  var  moveRightFrames = [
        SKTexture(imageNamed: "guest1-13"),
        SKTexture(imageNamed: "guest1-14")
    ]
    
   var moveDownFrames = [
        SKTexture(imageNamed: "guest1-7"),
        SKTexture(imageNamed: "guest1-8")
    ]
    
  var  standFrame = SKTexture(imageNamed: "guest1-9")
    
   var sitFrames = [
        SKTexture(imageNamed: "guest1-10"),
        SKTexture(imageNamed: "guest1-11"),
        SKTexture(imageNamed: "guest1-12")
    ]
    
  var  SheikhmoveUpFrames = [
        SKTexture(imageNamed: "Sheikh-1"),
        SKTexture(imageNamed: "Sheikh-3")
    ]
    
   var  SheikhmoveLeftFrames = [
        SKTexture(imageNamed: "Sheikh-10"),
        SKTexture(imageNamed: "Sheikh-12")
    ]
    
    var SheikhmoveRightFrames = [
        SKTexture(imageNamed: "Sheikh-4"),
        SKTexture(imageNamed: "Sheikh-6")
    ]
    
   var SheikhmoveDownFrames = [
        SKTexture(imageNamed: "Sheikh-7"),
        SKTexture(imageNamed: "Sheikh-9")
    ]
    
   var SheikhstandFrame = SKTexture(imageNamed: "Sheikh-8")
    
    var SheikhsitFrames = [
        SKTexture(imageNamed: "Sheikh-13"),
        SKTexture(imageNamed: "Sheikh-14")
    ]
    
    
    
    init(path: String, guestName: String, guestArea: String, GuestType:String) {
        self.guestPath=path
        self.guestName = guestName
        self.guestArea=guestArea
        self.guestType=GuestType
        
        
        
        character = SKSpriteNode(texture: standFrame)
        character.size = standSize // استخدام مقاس الوقوف
        character.position = initialPosition
        character.name = guestName
    }
    
    func addCharacter(to scene: SKScene) {
        character.zPosition = 1
        if character.parent == nil {
            scene.addChild(character)
        }
    }
    
    
    //creats the movement from intial point to the chair
        func startMovement(scene: SKScene) {
            guard let path = paths[guestName.replacingOccurrences(of: "guest", with: "path")]
            else {
                print("Error: Unable to retrieve points for \(guestName)")
                return
            }

            let entryPoint = CGPoint(x: 320, y: -155.297)
            let middlePoint = path[0]
            let setPoint = path[1]
            let delay = 1.10

           
            addCharacter(to: scene)
            
            // Action for moving to the entry point
            let moveToEntryPoint = SKAction.run {
                self.moveCharacter2(to: entryPoint, duration: 1.0,direction: "up")
            }
            
            // Action for moving to the middle point
            let moveToMiddlePoint = SKAction.run {
                if(middlePoint.x>444.00)
                {
                    self.moveCharacter2(to: middlePoint, duration: 1.0, direction: "right")
                }
                else
                {
                    self.moveCharacter2(to: middlePoint, duration: 1.0, direction: "left")
                }
               
            }
            
            // Action for moving to the set point
            let moveToSetPoint = SKAction.run {
                self.moveCharacter2(to: setPoint, duration: 1.0,direction:"up")
            }
            
            // Action to set the character after movement
            let setCharacterAction = SKAction.run {
                self.setCharacter()
            }
            
            // Create a sequence of actions with delays between them
            let movementSequence = SKAction.sequence([
                moveToEntryPoint,
                SKAction.wait(forDuration: delay),
                moveToMiddlePoint,
                SKAction.wait(forDuration: delay),
                moveToSetPoint,
                SKAction.wait(forDuration: delay),
                setCharacterAction
                
            ])
            
            // Run the sequence
            character.run(movementSequence)
        }
    
    // make movement from chair to the exit point
    
    func delay(_ delay: TimeInterval, closure: @escaping () -> Void) {
        DispatchQueue.main.asyncAfter(deadline: .now() + delay, execute: closure)
    }
    
    func exitMovement() {
        self.stand()
        delay(0.8)
        {
            self.character.removeAllActions()
            guard let path = self.paths[self.guestName.replacingOccurrences(of: "guest", with: "path")]
            else {
                print("Error: Unable to retrieve points for \(self.guestName)")
                return
            }
            
            let middlePoint = path[0]
            let exitPoint = CGPoint(x: -384.676, y: -155.297)
            let endPoint = CGPoint(x: -384.676, y: -800)
            
            let delay = 1.20 // Adjust the delay time as needed
            
            // Action for moving to the middle point
            let moveToMiddlePoint = SKAction.run {
                self.moveCharacter2(to: middlePoint, duration: 1.0, direction: "down")
            }
            
            // Action for moving to the exit point
            let moveToExitPoint = SKAction.run {
                if(middlePoint.x < -439.00)
                {
                    self.moveCharacter2(to: exitPoint, duration: 1.0, direction: "right")
                }
                else
                {
                    self.moveCharacter2(to: exitPoint, duration: 1.0, direction: "left")
                }
            }
            
            // Action for moving to the end point
            let moveToEndPoint = SKAction.run {
                self.moveCharacter2(to: endPoint, duration: 1.0, direction: "down")
            }
            
            // Create a sequence with delays between each movement
            let movementSequence = SKAction.sequence([
                moveToMiddlePoint,
                SKAction.wait(forDuration: delay),
                moveToExitPoint,
                SKAction.wait(forDuration: delay),
                moveToEndPoint
            ])
            
            // Run the sequence
            self.character.size=self.standSize
            self.character.run(movementSequence)
        }
    }
    
    func exitMovement2() {
      
            self.character.removeAllActions()
            guard let path = self.paths[self.guestName.replacingOccurrences(of: "guest", with: "path")]
            else {
                print("Error: Unable to retrieve points for \(self.guestName)")
                return
            }
            
            let middlePoint = path[0]
            let exitPoint = CGPoint(x: -384.676, y: -155.297)
            let endPoint = CGPoint(x: -384.676, y: -800)
            
            let delay = 1.20 // Adjust the delay time as needed
            
            // Action for moving to the middle point
            let moveToMiddlePoint = SKAction.run {
                self.moveCharacter2(to: middlePoint, duration: 1.0, direction: "down")
            }
            
            // Action for moving to the exit point
            let moveToExitPoint = SKAction.run {
                if(middlePoint.x < -439.00)
                {
                    self.moveCharacter2(to: exitPoint, duration: 1.0, direction: "right")
                }
                else
                {
                    self.moveCharacter2(to: exitPoint, duration: 1.0, direction: "left")
                }
            }
            
            // Action for moving to the end point
            let moveToEndPoint = SKAction.run {
                self.moveCharacter2(to: endPoint, duration: 1.0, direction: "down")
            }
            
            // Create a sequence with delays between each movement
            let movementSequence = SKAction.sequence([
                moveToMiddlePoint,
                SKAction.wait(forDuration: delay),
                moveToExitPoint,
                SKAction.wait(forDuration: delay),
                moveToEndPoint
            ])
            
            // Run the sequence
            self.character.size=self.standSize
            self.character.run(movementSequence)
        
    }


        
    

    
    //move the character to specific point
    func moveCharacter2(to location: CGPoint, duration: TimeInterval, direction: String) {
        // Stop any existing "walking" animation
        character.removeAction(forKey: "walking")
        character.size=standSize
        
        // Determine the direction and set the appropriate animation
        var moveFrames: [SKTexture] = []
        
        if direction == "up" {
            if guestType == "guest" {
                moveFrames = moveUpFrames
            } else {
                moveFrames = SheikhmoveUpFrames
            }
        } else if direction == "down" {
            if guestType == "guest" {
                moveFrames = moveDownFrames
            } else {
                moveFrames = SheikhmoveDownFrames 
            }
        } else if direction == "left" {
            if guestType == "guest" {
                moveFrames = moveLeftFrames
            } else {
                moveFrames = SheikhmoveLeftFrames
            }
        } else if direction == "right" {
            if guestType == "guest" {
                moveFrames = moveRightFrames
            } else {
                moveFrames = SheikhmoveRightFrames
            }
        }
        
        if !moveFrames.isEmpty {
            character.run(SKAction.repeatForever(SKAction.animate(with: moveFrames, timePerFrame: 0.1)), withKey: "walking")
        }
        
        // Create an action to move the character to the specified location
        let moveAction = SKAction.move(to: location, duration: duration)
        
        // Create an action to stop the walking animation after the movement is complete
        let stopWalkingAction = SKAction.run {
            self.character.removeAction(forKey: "walking")
        }
        
        // Run the movement action followed by stopping the walking animation
        character.run(SKAction.sequence([moveAction, stopWalkingAction]))
    }


    
    
    
    //make the character set
    func setCharacter() {
        // Stop any existing "walking" animation
        character.removeAction(forKey: "walking")
        
        // Change the character's size while sitting
        character.size = sitSize
        
        let sitTexture: SKTexture
        // Create the texture for the sitting position
        if(guestType=="guest")
        {
             sitTexture = SKTexture(imageNamed: "guest1-10")
        }
        else
        {
             sitTexture = SKTexture(imageNamed: "Sheikh-13")
        }
       
            
        
        // Apply the sitting texture directly to the character
        character.texture = sitTexture
        
        // Optionally, if you want to add a short sitting animation with the same texture:
        let sitAction = SKAction.setTexture(sitTexture)
        
        // Run the action (you can replace it with any other relevant action if needed)
        character.run(sitAction, withKey: "sitting")
    }
    
    

    
    func drinkingCharacter() {
        // Ensure any existing animation is stopped
        hasDrink = true 
        character.removeAction(forKey: "sitting")
        character.size = sitSize
        
        var drinkgingFrames: [SKTexture] = []
        
        if guestType=="guest"
        {
            drinkgingFrames=sitFrames
        }
        else
        {
            drinkgingFrames=SheikhsitFrames
        }
        // Create the sitting/drinking animation
        let drinkAction = SKAction.animate(with: drinkgingFrames, timePerFrame: 0.5)
        
        // Calculate the total time for one cycle of the animation
        let animationDuration = Double(drinkgingFrames.count) * 0.1
        
        // Calculate the number of times to repeat within 1.5 seconds
        let repeatCount = Int(1.75 / animationDuration)
        
        // Repeat the drinking animation for the calculated number of times
        let repeatDrinkAction = SKAction.repeat(drinkAction, count: repeatCount)
        
        // Run the repeating drinking animation
        character.run(repeatDrinkAction, withKey: "sitting")
    }



   //whole funciton changed
    func stand() {
        // Ensure any existing action is stopped
        character.removeAction(forKey: "standing")
        character.size = standSize

        // Create the stand texture
        let standTexture: SKTexture
        if guestType == "guest" {
            standTexture = standFrame
        } else {
            standTexture = SheikhstandFrame
        }

        // Create the action to set the stand texture
        let standAction = SKAction.setTexture(standTexture)

        // Create a delay action to wait for 0.8 seconds before completing
        let delayAction = SKAction.wait(forDuration: 0.8)

        // Combine the stand action and the delay in a sequence
        let standSequence = SKAction.sequence([standAction, delayAction])

        // Run the sequence on the character
        character.run(standSequence, withKey: "standing")
    }


    



  


   
    
    
}
