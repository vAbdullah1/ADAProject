import Foundation
import SpriteKit

class TimerManager {
    private var timerLabel: SKLabelNode
    private var countdownTimer: Timer?
    private var remainingTime: Int
    private weak var scene: SKScene?
    
    // إضافة الخاصية timeLeft
    var timeLeft: Int {
        return remainingTime
    }

    init(initialTime: Int, label: SKLabelNode, scene: SKScene) {
        self.remainingTime = initialTime
        self.timerLabel = label
        self.scene = scene
        setupTimerLabel()
    }

    private func setupTimerLabel() {
        timerLabel.text = String(format: "%02d  %02d", remainingTime / 60, remainingTime % 60)
        timerLabel.fontSize = 50
        timerLabel.fontColor = .black
        timerLabel.zPosition = 4
        scene?.addChild(timerLabel)
    }

    func startTimer() {
        countdownTimer = Foundation.Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(updateTimer), userInfo: nil, repeats: true)
    }

    @objc private func updateTimer() {
        if remainingTime > 0 {
            remainingTime -= 1
            let minutes = remainingTime / 60
            let seconds = remainingTime % 60
            timerLabel.text = String(format: "%02d  %02d", minutes, seconds)
        } else {
            countdownTimer?.invalidate()
            // switchToNextScene()
        }
    }

    private func switchToNextScene() {
        if let scene = scene as? GameScene {
            //let nextScene = AnotherGameScene(size: scene.size)
            //nextScene.scaleMode = .aspectFill
            //let transition = SKTransition.fade(withDuration: 1.0)
            //scene.view?.presentScene(nextScene, transition: transition)
        }
    }

    func stopTimer() {
        countdownTimer?.invalidate()
    }
}
