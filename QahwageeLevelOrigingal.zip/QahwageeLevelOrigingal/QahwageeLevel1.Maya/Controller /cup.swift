import SpriteKit

class Cup: SKSpriteNode {

    private var dropAction: SKAction!
    static var brokenCupCount = 0 // Static variable to keep track of broken cups
    static let maxCups = 3 // Total number of cups
    private let fullSize = CGSize(width: 50, height: 75)
    private let brokenSize = CGSize(width: 250, height: 150)
    private var hasDropped = false // Flag to track if the drop has already occurred

    init(xPosition: CGFloat) {
        let texture = SKTexture(imageNamed: "cup_full")
        super.init(texture: texture, color: .clear, size: fullSize)
        self.position = CGPoint(x: xPosition, y: 112.00) // Assuming y is constant
        setupActions()
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupActions() {
        let dropTexture = SKTexture(imageNamed: "cup_dropped")
        let breakTexture = SKTexture(imageNamed: "cup_broken")
        
        dropAction = SKAction.sequence([
            SKAction.moveTo(y: 80, duration: 0.5), // Move to y=80
            SKAction.setTexture(dropTexture),
            SKAction.wait(forDuration: 0.2),
            SKAction.setTexture(breakTexture),
            SKAction.scale(to: brokenSize, duration: 0.1),
            SKAction.playSoundFileNamed("breakingglass.mp3", waitForCompletion: false)
        ])
    }

    func drop(in scene: SKScene) {
        guard !hasDropped else { return } // Prevent the drop if it has already happened

        self.size = fullSize
        self.zPosition = 1
        scene.addChild(self)
        hasDropped = true // Mark the drop as happened

        self.run(self.dropAction) {
            Cup.brokenCupCount += 1
            if Cup.brokenCupCount >= Cup.maxCups {
                if let playScene = scene as? PlayScene {
                    playScene.transitionToGameOver()
                }
            }
        }
    }
}
