import Foundation
import SpriteKit

class CupCounter {
    private var coffeeCountLabel: SKLabelNode!
    private var maxCountLabel: SKLabelNode!
    private var cupDropCount: Int = 0
    private let maxCups: Int
    private let scene: SKScene
    var hasCupBroken: Bool = false

    init(maxCups: Int, scene: SKScene) {
        self.maxCups = maxCups
        self.scene = scene
        setupCoffeeCountLabel()
        setupMaxCountLabel()
    }

    private func setupCoffeeCountLabel() {
        coffeeCountLabel = SKLabelNode(fontNamed: "Pixel Emulator")
        coffeeCountLabel.fontSize = 50
        coffeeCountLabel.fontColor = .black
        coffeeCountLabel.position = CGPoint(x: -1154.521, y: 500) // Position on the left side of the screen
        coffeeCountLabel.zPosition = 2
        coffeeCountLabel.text = "0"
        scene.addChild(coffeeCountLabel)
    }

    private func setupMaxCountLabel() {
        maxCountLabel = SKLabelNode(fontNamed: "Pixel Emulator")
        maxCountLabel.fontSize = 50
        maxCountLabel.fontColor = .black
        maxCountLabel.position = CGPoint(x: -1034.157, y: 500)
        maxCountLabel.zPosition = 2
        maxCountLabel.text = "\(maxCups)" // Max coffee count
        scene.addChild(maxCountLabel)
    }

    func dropCupCount() {
        if cupDropCount < maxCups {
            cupDropCount += 1
            updateCountLabel()
        }
    }

    private func updateCountLabel() {
        coffeeCountLabel.text = "\(cupDropCount)"
    }

    func hasReachedMaxCups() -> Bool {
        return cupDropCount >= maxCups
    }
}
